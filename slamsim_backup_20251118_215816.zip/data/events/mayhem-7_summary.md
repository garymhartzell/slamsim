### Tag-Team Match
#### The Void (Luke Graves, Vincent Van Ives), Riddick vs Knightfall (Chris Davids, John Blair), Timothy Myers



---

### Singles Match
#### Apalachi vs Bobby Biceps vs Michael King

3-Way match. Apalachi wins with the MBA on King.

---

### Tag-Team Match
#### Hot Shots (Abigail James, Danielle Marks), Jessica James vs Diamond Princesses (Dana Diamond, Kiara Haddad), Anastasia Phoenix

Women's Trios Match