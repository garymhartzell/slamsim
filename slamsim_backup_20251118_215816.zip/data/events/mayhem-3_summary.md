### Tag-Team Match
#### Las Chicas Viciosas vs Erika Lewis, Marie Ross

The opening televised match saw Elaina Sanchez and Rita Gomez, AKA Las Chicas Viciosas, completely dominate Erika Lewis and Marie Ross. After the match, Gomez grabbed the microphone, shouting “That’s how you do iot, bitches! We will be the first WMA Tag-Team Champions!”


---

### Women 3-Way Match
#### Allison Katt vs Apryl Raser vs Autumn Chambers

Next was a 3-way match: Apryl Raser vs. Autumn Chambers vs. the debutting Allison Katt. Katt had the crowd on her side and rode the wave of momentum, almost getting a pinfall on Chambers, then on Raser. Raser was especially vicious tonight, at one point cracking Chambers in the back with a steel chair. Despite this, Autumn hit a curb stomp on Allison Katt on the steel steps and got her back in the ring for the pin.


---

### Tag-Team Match
#### The Hooligans vs The Texas Badlanders

The Hooligans made their debut, but it was against Foul Frank and Wild Bill. Despite the odds, Walker and Wilson got several near falls, but in the end, it was the Texans with Sorry About Your Damn Luck for the pin and the win.

---

### Tag-Team Match
#### The Mad Dogs vs The Pumas

A great tag-team contest followed; a match that went over 15 minutes as The Mad Dogs faced The Pumas. In the end, The Mad Dogs got the win over Noah and Killian Brady with The Dog Pile.

---

### Singles Match
#### Apalachi vs KC Shore

Apalachi vs. the debutting KC Shore was a hard hitting match. Shore initially frustrated the larger man with his speed, but eventually, Apalachi hit a spear that turned KC inside-out. He continued to punish Shore, placing him in the MBA (bearhug), but Shore punched his way out of it. KC’s comeback was topped off with his Kickstarter to Apalachi’s face, getting the 1-2-3.


---

### Singles Match
#### Jamey Kingston vs Jim Brady

Jamey Kingston and Jim Brady squared off next. They traded pinfall attempts, but it was “The Jamaican Giant” who got the one that counted after hitting The Tripole Triple.


---

### Main Event - Tag-Team Match
#### Alexi Chambers, Scott Ashton vs Rick Walker, TJ Valentine

The Main Event saw Alexi Chambers and Scott Ashton against Rick Walker and TJ Valentine. The match spilled out to the floor, causing Flagg to get involved, choking Valentine behind the referee’s back. Johnny Destruction was also at ringside and took cheap shots at both Valentine and Walker. In the end, it was too much for the good guys, and The Hellfire Club got the win. They continued to beat down Walker and Valentine after the bell until The Shore Bros and The Hooligans came out for the much needed save.