### Heavyweight Tournament First Round Match
#### Jamey Kingston vs Joe Shore

Next was the opening match of the Heavyweight Championship Tournament. Jamey Kingston faced Joe Shore. Shore looked to have the match won after his big right fist (Boom!“ but Kingston got a foot on the ropes. Shore kept on top of Kingston. A superkick by Joe was countered by Kingston into his triple powerbomb, The Tripoli Triple, and the win.

---

### Heavyweight Championship Tournament First Round Match
#### Fitzgerald vs Alexi Chambers

The second match in the tournament saw Fitzgerald up against Alexi Chambers. Although Fitzgerald was the odds-on favorite, his distraction with looking for the Happy Faces worked in Chambers’ favor. Fitzgerald went for Spin Til You Hurl (an airplane spin), but Alexi counted with a roll-up. Holding the tights, Alexi got the upset.


---

### Tag-Team Tournament Qualifier
#### Adrenaline vs Las Chicas Viciosas

Smack talk and pushing and shoving is how the women’s tag-team match started, but Regina Cassidy was able to restore order and the teams of Las Chicas Viciosas and Too Sweet put on a tag-team wrestling clinic for the majority of the bout. Sanchez and Gomez showed why they were labelled as “vicious,” however, punishing the Too Sweet girls outside of the ring, involving weapons behind Cassidy’s back. Las Chicas ultimately got the pinfall victory.

---

### Heavyweight Championship Tournament First Round Match
#### TJ Valentine vs Michael King

TJ Valentine faced Michael King in the next tournament match, and this was nothing short of a brawl. Valentine with a bulldog from the top turnbuckle secured advancement.

---

### Heavyweight Championship Tournament First Round Match
#### Jim Brady vs Scott Ashton

In the fourth match of the first round of the Heavyweight Championship tournament, “Gentleman” Jim Brady, despite being a higher placement, found himself in a hard fought battle against Scott Ashton. Add Evander Flagg to the mix, and it only got harder. Ashton was a hair from putting Brady away with his Apocolypse Powerbomb, but Brady got a shoulder up. Brady fought back into the match with forearms and knife-edge chops. A double knee facebreaker, and he got the 1-2-3.

---

### Main Event
#### The Mad Dogs vs The Texas Badlanders

In the Main Event, The Texas Badlanders and the Mad Dogs fought until there was blood, and beyond. The winner would be named the top seat in the tag-team tournament, and rightfully so. Rated Extreme (Dynamite and Payne) made their presence known, distracting Frank and Bill, and this ultimately cost them the match.

After the match, Payne and Dynamite entered the ring. The Mad Dogs were not interested in whatever was about to come down, so they left and the other four slugged it out until Mayhem went off the air.