### Singles Match
#### KC Shore vs Luke Graves

The air in the arena thrummed with anticipation as the opening bell echoed, signaling the start of Mayhem #10’s first contest. KC Shore, “Rock and Roll,” bounced on the balls of his feet, a vibrant contrast to the brooding presence of Luke Graves, “The War Machine.”

“And we are officially underway, Phil Mesa here, alongside Grant Kowalski and Jefferson Turner, for what promises to be an explosive opener!” Phil Mesa’s voice boomed over the PA.

“Explosive indeed, Phil. Two powerhouses of their respective factions, though I daresay only one here is truly built for war,” Grant Kowalski immediately sided with Graves.

“Come on, Grant, Shore’s got more heart and speed than Graves has pure muscle. Don’t count out the ‘Rock and Roll’ just yet!” Jefferson Turner countered, his voice full of hope for the hero.

The match began with a furious exchange of holds, Shore's technical prowess and agility allowing him to evade Graves' initial power-based attacks. He weaved in and out, delivering quick arm drags and dropkicks that sent the larger Graves stumbling. Graves, however, quickly regained his footing, his 6’3”, 252 lbs frame a solid wall against Shore’s 6’1”, 215 lbs frame. He caught Shore mid-air during a cross-body attempt, slamming him down with a sickening thud.

“See that, Jeff? Size and power always win out. Shore’s little flippy moves are just an appetizer for the main course,” Kowalski sneered.

“He caught him, yes, but Shore’s resilience is unmatched, Grant! He’ll be back up!” Turner insisted.

Graves took control, transitioning into a brutal brawling style. He pounded Shore in the corner with stiff strikes and shoulder tackles, then hoisted him for a crushing Spinebuster that left the hero gasping. The referee, Jose Pappas, checked on Shore, but Graves dragged him up, clearly not finished. He stomped at Shore, then locked him in a headlock, squeezing the life out of him.

“Luke Graves is a machine, a true force of nature! Shore might be all flash, but Graves is pure substance,” Kowalski gloated.

“He’s just trying to wear him down, Phil. That’s smart, but Shore’s cardio is legendary,” Mesa noted, as Shore began to fight back, slowly, methodically.

Shore managed to slip out of a hold and hit a flurry of rapid-fire kicks, culminating in a jumping enzuigiri that briefly rocked Graves. Sensing an opening, Shore climbed to the top turnbuckle, looking for a high-flying maneuver. But Graves, recovering quickly, sprinted to the ropes, shoving them hard. Shore lost his balance, tumbling awkwardly to the outside.

“Oh, that was nasty! Shore landed hard on the floor!” Mesa exclaimed.

Graves leaned out, yelling at Referee Pappas, demanding he start the count. As Pappas’s attention was fully focused on Graves, a dark figure emerged from under the ring – Vincent Van Ives, a member of The 7th Circle, Graves’s faction! Van Ives grabbed the dazed KC Shore, hoisted him high, and delivered a sickening bodyslam onto the unforgiving arena floor!

“What the?! Jose Pappas is completely oblivious!” Turner roared, his voice laced with outrage. “That’s Van Ives! He just laid out Shore!”

“Oh, what’s the big deal, Jeff? Just a little, uh, 'motivational boost' from a friend. Happens all the time. Part of the game,” Kowalski scoffed, trying to downplay the blatant interference.

Graves then casually tossed Shore back into the ring, a predatory grin spreading across his face. He wasted no time, dropping a massive elbow, then transitioning into a devastating **War Machine Slam**. Graves hooked the leg, but Shore kicked out at a very close two count!

“How did he kick out of that?! That’s the War Machine Slam!” Kowalski shrieked in disbelief.

“The heart of a hero, Grant! The will to win!” Turner cheered, relief washing over him.

Graves, visibly frustrated, pounded the mat. He pulled Shore to his feet, delivering a thunderous **Graves Marker** lariat that nearly decapitated "Rock and Roll." He went for another pin, but Shore, on pure instinct, again kicked out at two! Graves continued his assault, slamming Shore into the turnbuckle, then unleashing a barrage of strikes. He tried for another power move, but Shore managed to counter, hitting a desperate superkick that created just enough space.

Shore, dazed but determined, started to find his second wind. He dodged a charging Graves, sending him shoulder-first into the ring post. With Graves reeling, Shore climbed the turnbuckle again, but Graves recovered and yanked him down. Enraged, Graves grabbed Shore and, roaring in frustration, attempted to throw him *over* the top rope to the floor, aiming to end the match via count-out or disqualification.

“Graves has lost his temper! He’s trying to throw Shore out of the ring!” Mesa shouted.

However, as Shore sailed over the top rope, his instincts kicked in. He managed to grab the top rope, dangling precariously. With a sudden burst of adrenaline, he swung his legs up, using the ropes for leverage, and launched himself back into the ring, flying directly at the surprised Luke Graves! He connected with a devastating **KC Catapult** – a springboard flying cutter – that sent Graves crashing to the canvas!

The crowd erupted! Shore quickly covered Graves, hooking the leg tightly. One... Two... THREE!

“He did it! KC Shore has done it!” Phil Mesa roared, almost losing his voice. “The ‘Rock and Roll’ finds a way! An incredible finish!”

“No! No, no, no! That was a fluke! Graves had him dead to rights! That cheating Van Ives interference should have won him the match!” Kowalski screamed, absolutely beside himself.

“YES! He overcame the odds, Grant! He overcame the size, the power, and the blatant interference! That’s why KC Shore is a hero!” Turner was on his feet, applauding furiously.

The referee’s arm shot down for the final count at 13:40. KC Shore, battered and bruised, slowly rose to his feet, his arm raised in victory as the arena exploded in cheers. Luke Graves lay motionless, stunned by the sudden turn of events, while Vincent Van Ives stared in disbelief from ringside, their plan having backfired spectacularly. What a start to Mayhem #10!

---

### 

Backstage Gemma Stiles interviewed Adrian Waters, who was upset he wasn't in tonight's main event after pinning the champion in a non-title match last week. He demanded his shot next week.

---

### Main Event - WMA World Championship
#### Timothy Myers vs Johnny Destruction

**Segment 3: Main Event - WMA World Championship**

The arena lights dim, and a hush falls over the raucous crowd. Ring announcer Brad Ellering steps into the center of the ring, his voice booming through the speakers. "Ladies and gentlemen, it is time for your Main Event of the evening! This match is sanctioned for the World Martial Arts World Heavyweight Championship!"

A low, guttural growl rips through the arena sound system, accompanied by a heavy, industrial rock beat. The titantron explodes with images of urban decay and shattered glass as **Johnny Destruction** strides out onto the stage. The 6-foot-3, 280-pound powerhouse, clad in black trunks and boots, looks like a force of nature. His eyes are fixed on the ring, a cold, predatory glint in them. He walks with a deliberate, unhurried pace, soaking in the mixed reactions of the crowd – some awe-struck, others genuinely fearful. He pauses at the apron, climbs the steel steps with intimidating power, and then steps over the top rope, staring down the camera with an almost unsettling intensity. He slowly turns, surveying the empty side of the ring where his opponent will soon stand.

"And his opponent, weighing in at 280 pounds, from parts unknown, 'The Annihilator' **Johnny Destruction!**" Ellering announces, a slight tremor in his voice.

"Look at this kid, Phil," Grant Kowalski's voice cuts through the silence. "He’s got that look in his eye. He's not here to play games. He’s here for gold."
"Johnny Destruction has been on an absolute tear since arriving in WMA, Grant. This is the biggest opportunity of his career," Phil Mesa adds, his tone neutral but impressed.
"And he’s earned it. He's a true beast," Jefferson Turner concedes, though his tone suggests he's wary of Destruction's methods.

The lights shift to a bright, vibrant white as a driving, melodic rock anthem fills the arena. The crowd erupts as the WMA World Champion, **Timothy Myers**, "The Rebel," emerges. The 6-foot-5, 240-pound All-Rounder carries the championship belt proudly over his shoulder, a confident smirk playing on his lips. He's met with a hero's welcome, high-fiving fans as he makes his way down the ramp. His movements are fluid and assured, a stark contrast to Destruction's raw power. He steps into the ring, lifts the championship high above his head to a thunderous ovation, then hands it to the referee. He then turns to face Destruction, a determined glint in his eye, but also an undeniable respect for the challenge before him.

"And his opponent, the reigning, defending, and undisputed WMA World Heavyweight Champion, weighing in at 240 pounds, 'The Rebel' **Timothy Myers!**" Ellering's voice booms as the crowd roars.

The referee holds the championship high above both men, confirming what's at stake. Destruction tries to stare down Myers, but Myers just meets his gaze, unblinking. The referee calls for the bell.

The match begins with a furious exchange. Destruction immediately charges, using his superior weight to drive Myers into the corner with a powerful shoulder tackle. He unleashes a flurry of heavy clubbing blows to Myers' back and ribs, displaying his brawler instincts. Myers, though momentarily stunned, uses his agility to slip out from under Destruction's arm and delivers a quick, precise knee lift to the midsection, momentarily creating space.

"Johnny Destruction isn't wasting any time establishing his dominance. He wants to end this quickly," Kowalski observes, clearly enjoying the brutality.
"Myers is going to have to rely on his speed and technical skill to overcome that raw power, Grant. Destruction is a brick wall," Turner replies, concern in his voice.

The contest quickly devolves into a brutal back-and-forth war. Destruction's powerhouse style is on full display as he catches Myers attempting a crossbody, then slams him to the mat with a thunderous scoop slam. He follows up with a series of gut wrenches and a devastating German suplex that sends Myers flying across the ring. Destruction repeatedly tries to overpower Myers, attempting a massive chokeslam, but Myers manages to twist out of it at the last second, landing on his feet.

Myers, the All-Rounder, begins to pick his spots, using his technical prowess to target Destruction's legs with sharp kicks and a series of dragon screws. He tries to chop down the larger man, but Destruction shrugs off many of the blows, often answering with a stiff jab or a powerful forearm that echoes through the arena. The match spills to the outside, where Destruction, embodying his brawler style, sends Myers crashing into the barricade with a vicious lariat, then grinds his boot into Myers' face, ignoring the referee's count.

Back in the ring, Destruction starts to build momentum. He hits a massive Spinebuster, folding Myers in half. He covers for the pin. ONE! TWO! Myers kicks out!
"So close! Johnny just about had him!" Kowalski yells, pounding the announce desk.
"Myers has the heart of a champion, Grant. He's not going down that easily," Turner counters.

Destruction, frustrated, drags Myers back up, attempting a powerbomb. Myers struggles, trying to counter, but Destruction muscles him up, delivering a brutal Sit-out Powerbomb that shakes the ring. He goes for another pin! ONE! TWO! A visible struggle from Myers! He kicks out again!
"Oh, come on! How many more does Myers have to take?" Phil Mesa exclaims, even he surprised by Myers' resilience.

The match stretches past the 15-minute mark, then the 20-minute mark. Both men are visibly exhausted, sweat plastering their hair to their foreheads, chests heaving. Destruction has landed multiple big moves, getting nearly as many near falls as Myers. He sets up Myers for what looks like another destructive finisher, but Myers, with the crowd roaring behind him, ducks a clothesline, then springs off the ropes and connects with a powerful Rebound Lariat, finally dropping the larger man to one knee.

Myers sees his opening. He staggers, but his eyes are alight with determination. He grabs the dazed Johnny Destruction, hooks his arm, and hoists him up onto his shoulders in a devastating Argentine Backbreaker Rack position. The crowd rises to its feet, sensing the end. Myers spins, dropping Destruction face-first into a brutal Piledriver. **ROCK YOUR WORLD!**

The impact sends a shockwave through the arena. The sound of the crowd's collective gasp is almost deafening, immediately followed by a chorus of "HOLY SHIT!" chants reverberating through the building. Myers falls forward, hooking Destruction's leg for the cover.

ONE!
TWO!
THREE!

The referee's hand slaps the mat for the final time!

The bell rings! The arena explodes!

"MYERS! TIMOTHY MYERS RETAINS THE CHAMPIONSHIP!" Phil Mesa shouts over the din, pure adrenaline in his voice.
"I don't believe it! After everything Johnny Destruction threw at him, Myers still found a way! What a match!" Jefferson Turner roars, elated.
"He got lucky! One move! That's all it was! Johnny was dominant for 90% of that match!" Kowalski protests, his voice filled with frustration.

Timothy Myers struggles to his feet, battered and bruised, but triumphant. He is handed his WMA World Championship, which he hoists high above his head, roaring in defiance and celebration. The crowd is on its feet, giving him a well-deserved standing ovation. Johnny Destruction lies motionless in the ring for a moment before slowly stirring, disbelief and raw anger etched across his face as he stares blankly at the champion celebrating in the corner. Myers looks down at his vanquished opponent, a respectful nod, acknowledging the fight, before continuing his celebration, still the WMA World Champion.