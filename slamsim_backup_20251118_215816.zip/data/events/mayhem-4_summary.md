### Singles Match
#### Bobby Biceps vs Don Real

In the opening television match, “The Golden Stud” Bobby Biceps made his WMA debut against Don Real. Real caught Biceps with a forearm and a dropkick, and a few other moves; but that was about it. Bobby controlled the rest of the contest, putting Real away with the Lethal Knee Move.


---

### Floyd's Address

In the ring, Pete Floyd announced that many of tonight’s matches would allow him to complete the brackets for the Heavyweight Championship tournament, which would start next week, and would conclude at WMA’s first PPV event, All-American Showdown on July 10 from Philadelphia.

---

### Singles Match
#### Arsen vs Allison Katt

Allison Katt then took on the woman known as Arsen. Arsen was vicious, taking control with an eye rake. Arsen tormented Katt on the floor before being forced back into the ring by Regina Cassidy. Arsen went for a corkscrew cross-body, but Allison ducked it. Allison worked on Arsen’s leg, then locked in Plie (a figure four) and Arsen tapped out.

---

### Match
#### The Pumas vs Chris Baer, Eric Baer

The next match saw The Pumas get on track, defeating the Baer brothers in five minutes after hitting “Puma Power.

---

### Six-Woman Tag-Team Match
#### Diamond Princesses vs California Connection

Kiara Haddad, Dana Diamond, Mandy Matthews vs. Amber Sloane, Apryl Raser, Tammy Terrel: This match got out of hand from the very beginning when the Diamond/Haddad/Matthews team overwhelmed their opponents, forcing them to retreat to the floor. Raser started for her team, attempting to slow things down. Apryl’s team isolated Kaira and got a few near falls, but Haddad was able to make the hot tag to Mandy. Mandy and Dana kept Sloane from her partners and got a near fall, but Terrel broke it up. All hell broke looseand this worked to the heel’s advantage, the vetern Raser hitting Kiara with “The Widow’s Kiss” getting the pin.

---

### Elimination Match
#### Extreme Randy vs Frank Roberts vs Jamey Kingston vs Max Dynamite vs Scott Ashton

Next up was a five wrestler elimination match. “Foul” Frank was the first to be eliminated after he threw Extreme Randy out of the ring; however, Randy held on to the ropes, then lept off of the top. Roberts caught Randy, but then tyripped due to a Russian leg sweep from Max Dynamite, and Randy got the pin. Frank nailed both Max and Randy with lariats before leaving.Ashton covered Randy while Kingston covered Dynamite. Roger Ethridge got to the Ashton pin on Randy first, but Dynamite kicked out when Ethridge attempted to count that pin. The remaining three battled back and forth for quite a while, with Dynamite eliminating Ashton. Max and Kingston fought for another ten minutes before Kingston hit the Tripoli Triple, getting the win.

---

### Tournament Qualifier
#### Rick Walker vs Apalachi

Rick Walker vs. Apalachi was a World Championship tournament qualifier, and it was a very competitive match. It appeared Apalachi would win after hitting Power Down, but Walker got a foot on the ropes. Walker with a massive belly-to-belly suplex cemented the victory around the 15 minute mark.

---

### Extreme Badlanders

The scene goes backstage where The Texas Badlanders are attacking Max Dynamite. McGraw is holding Dynamite while Frank punches him, swearing and blaming him for his earlier elimination. “Monster” Payne makes the save, beating off both Texans with his kendo stick. before checking on his long time friend.

---

### Tournament Qualifier
#### Johnny Destruction vs KC Shore

KC Shore and Johnny Destruction had what turned out to be a bloody fight. In the end, Shore won by DQ when Alexi Chambers attacked Shore with a steel chair.

---

### Main Event
#### The Happy Faces vs Fitzgerald, Joe Shore

The Main Event had arrived. With Joe Shore stepping up to be Fitz's partner, Fitzgerald had a new-found confidence. They dominated The Happy Faces early on. The Faces nearly got counted out after fleaing, but Fitz and Shore ushered them back into the ring. A foreign object in Happy Sam’s tights was the difference maker, knocking out the knock-out expert, Joe Shore.

After the match, they attacked Fitzgerald and placed him in a straitjacket and frownie face mask. The show faded out on this image.