### Tag-Team Match
#### Sacred Dragons vs Chris Baer, Eric Baer

The Sacred Dragons had one hell of a battle against the Happy Faces in the first ever Mayhem Main Event one week ago, but coming up short didn’t sit well with them. They made Da Bad News Baers pay as a result. Chris and Eric could not put together any sort of offense against the Dragons, and the Dragons had the match won in under five minutes.

---

Backstage, John Thompson interviewed The Texas Badlanders, who put down their opponents tonight (Rated Extreme), as well as the entire tag-team division.

A backstage segment showed brothers Killian and Noah Brady talking strategy for Killian’s match against Fitzgerald. Killian pulled out a set of brass knuckles, which Noah snatched away from him. The two bickered, with Killian throwing up his hands in defeat.

Brenda McHale spoke with Anastasia, who discussed her debut win and her upcoming match.

---

### Singles Match
#### Apalachi vs Bill Long

Rudy Fresno was back out to the ring; this time with Apalachi. His opponent this week was Bill Long. Long had absolutely no offense against the huge Apalachi, who put him away in under three minutes.

After the match, Apalachi once again hit Long with a second, then a third Powerdown. That is when KC Shore came out on to the stage. Shore said if Apalachi liked beating up on smaller men, he (Shore) was smaller and up to the challenge. Apalachi smirked and gestured for KC to come on down. KC did just that, but was blocked by security. Pete Floyd came out and said he would have his shot at Apalachi…at the next Mayhem.


---

Brenda McHale interviewed The Mad Dogs, who expressed annoyance at not being booked. They wanted to be in action every week so there were no excuses when they won the Tag-Team tournament.

Evander Flagg and the Hellfire Organization talked about the main event and how the new heroes of WMA would be put to rest. 

John Thompson interviewed Katy Kelly, who was sporting shades and complaining about a hangover.

---

### Tag-Team Match
#### Adrenaline vs Arsen, Missy Wallace

It was a debut of four women as Too Sweet (Candi and Cookie) took on Missy Wallace and Arsen. A competitive match ended with Too Sweet hitting a doomsday device they call “Sugar Drop” and getting the 1-2-3.

After the match, the girls took the mic, thanking Matthews, Floyd, and the fans. They put forth an idea to the brass to allow women tag-teams to enter the tag-team tournament. That is whenGomez and Sanchez came out. They came down to the ring, bragging about how they were the best women’s tag-team and not a couple of blonde bimbos. Pushing and shoving ensued and security eventually had to intervene.

---

### Singles Match
#### Anastasia Phoenix vs Katy Kelly

Katy Kelly and Anastasia Pheonix also had a competitive match. Kelly almost put Pheonix away on several occasions, but Anastasia hit Rise of the Pheonix from out of nowhere, getting the pinfall.

---

Brenda McHale interviewed Jamey Kingston and Michael King. This was followed by a segment featuring Max Dynamite and “The Monster” Payne, who were discussing their forthcoming match against a team they hadn’t fought in 8 years…but they were ready.


---

### Singles Match
#### Fitzgerald vs Killian Brady

Killian Brady, with his brother Noah at ringside, had his work cut out for him against the fan favorite Fitzgerald. Killian did some low level cheating, buying him a couple of advantages, but ultimately, the Rediculous One pulled out the pinfall victory with a roll-up as Killian argued with Noah.

---

Brenda was backstage with Rudy Fresno, the Sacred Dragons, and Apalachi. Fresno said Apalachi was looking forward to tearing KC Shore limb-from-limb next week, and said the Dragons erased the fluke Happy Faces win last week and were on their way to being the first WMA Tag-Team Champions.

A backstage lockerroom segment aired where Killian was hot with brother Noah for costing him the match against Fitzgerald.

---

### Singles Match
#### Joe Shore vs Johnny Destruction

The next match was hard hitting as Johnny Destruction faced Joe Shore. It looked like Shore was going to put Destruction away with JKO, but Destruction avoided it, countering with the Eyes of Razor.

---

### Tag-Team Match
#### Rated Extreme vs The Texas Badlanders

The Texas Badlanders and Rated Extreme put on a tag-team clinic. So many near falls on both sides. Ultimately, the crowd was chanting "This is awesome" as the two teams reached the 20 minute time limit.

---

John Thompson interviewed Fitzgerald after the match. The interview was interrupted by the Happy Faces, who rode up on their golf carts. Happy Jack handed Fitz a note and a wrapped present. Fitzgerald read the note, which basically said it was good to have friends in this industry. He opened the present to reveal a Happy Faces mask inside. The team gestured for Fitz to try it on, but Fitzgerald declined, saying he knows of their reputation and he couldn’t be that way. The men nodded and started to drive off, although Sam backed the cart into Fitz, knocking the man over, before speeding off.

---

### Main Event
#### Alexi Chambers, Scott Ashton vs Jim Brady, Rick Walker

The Main Event was now upon us. Hellfire (Alexi Chambers and Scott Ashton) gave "Slick Rick Walker and "Gentleman" Jim Brady quite a battle, but in the end, the good guys prevailed with Walker getting the pin on Alexi.

After the match, a beat-down ensued, with Johnny Destruction joining in. The show ended with the good guys, including TJ Valentine, laid out in the center of the ring.